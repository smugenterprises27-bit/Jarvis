package com.example.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class JarvisService : Service(), TextToSpeech.OnInitListener {

    // Change this if Google renames the model
    private val model = "gemini-flash-latest"
    private val systemPrompt =
        "You are Jarvis, a friendly voice assistant. The user speaks Telugu. " +
        "Always reply in Telugu written in English letters (like casual WhatsApp chatting, e.g. \"nenu bagunna, nuvvu ela unnav?\"), in 1-2 short sentences. Never use Telugu script. No markdown, no emojis."

    private val handler = Handler(Looper.getMainLooper())
    private var voskModel: Model? = null
    @Volatile private var running = false
    @Volatile private var woke = false
    private var wakeThread: Thread? = null
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW)
        )
        val n: Notification = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis is listening")
            .setContentText("Say \"Jarvis\"")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
        if (tts == null) tts = TextToSpeech(this, this)
        startWakeWord()
        return START_STICKY
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        val r = tts?.setLanguage(Locale("en", "IN"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            toast("English (India) voice missing. Install it in Google Text-to-speech settings.")
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { handler.post { resumeWakeWord() } }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { handler.post { resumeWakeWord() } }
        })
    }

    private fun loadModel(): Model {
        voskModel?.let { return it }
        val root = File(filesDir, "vosk")
        if (!root.exists()) {
            val tmp = File(filesDir, "vosk_tmp")
            tmp.deleteRecursively()
            tmp.mkdirs()
            ZipInputStream(assets.open("model.zip")).use { zin ->
                var e = zin.nextEntry
                while (e != null) {
                    val f = File(tmp, e.name)
                    if (e.isDirectory) f.mkdirs() else {
                        f.parentFile?.mkdirs()
                        FileOutputStream(f).use { out -> zin.copyTo(out) }
                    }
                    e = zin.nextEntry
                }
            }
            tmp.renameTo(root)
        }
        val dir = root.listFiles()!!.first { it.isDirectory }
        val m = Model(dir.absolutePath)
        voskModel = m
        return m
    }

    private fun isWake(json: String): Boolean {
        val o = try { JSONObject(json) } catch (e: Exception) { return false }
        val t = (o.optString("text").ifEmpty { o.optString("partial") }).lowercase()
        return t.contains("jarvis") || t.contains("jar vis")
    }

    private fun startWakeWord() {
        if (wakeThread != null) return
        running = true
        woke = false
        wakeThread = Thread {
            try {
                val model = loadModel()
                val rec = Recognizer(model, 16000f)
                val minBuf = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val ar = AudioRecord(MediaRecorder.AudioSource.MIC, 16000,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 8000))
                ar.startRecording()
                val buf = ShortArray(4000)
                while (running) {
                    val n = ar.read(buf, 0, buf.size)
                    if (n > 0) {
                        val done = rec.acceptWaveForm(buf, n)
                        val txt = if (done) rec.result else rec.partialResult
                        if (isWake(txt)) { woke = true; running = false }
                    }
                }
                ar.stop()
                ar.release()
                rec.close()
            } catch (e: Exception) {
                toast("Wake word error: ${e.message}")
            }
            handler.post {
                wakeThread = null
                if (woke) onWake()
            }
        }.also { it.start() }
    }

    private fun resumeWakeWord() { startWakeWord() }

    private fun onWake() {
        try { ToneGenerator(AudioManager.STREAM_MUSIC, 100).startTone(ToneGenerator.TONE_PROP_BEEP) } catch (_: Exception) {}
        handler.postDelayed({ listen() }, 400)
    }

    private fun listen() {
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (text.isNullOrBlank()) resumeWakeWord() else ask(text)
            }
            override fun onError(error: Int) { resumeWakeWord() }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rms: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "te-IN")
        }
        recognizer?.startListening(i)
    }

    private fun ask(text: String) {
        Thread {
            val reply = callGemini(text)
            handler.post { speak(reply) }
        }.start()
    }

    private fun callGemini(text: String): String {
        return try {
            val key = getSharedPreferences("jarvis", MODE_PRIVATE).getString("gemini", "") ?: ""
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts",
                    JSONArray().put(JSONObject().put("text", systemPrompt))))
                .put("contents", JSONArray().put(JSONObject()
                    .put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))))
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            val c = url.openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key)
            c.doOutput = true
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
            val resp = stream.bufferedReader().readText()
            JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        } catch (e: Exception) {
            "Sorry, edo tappu jarigindi."
        }
    }

    private fun speak(text: String) {
        val t = tts
        if (t == null) { resumeWakeWord(); return }
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun toast(m: String) {
        handler.post { Toast.makeText(this, m, Toast.LENGTH_LONG).show() }
    }

    override fun onDestroy() {
        running = false
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
