package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val pad = (24 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        val gem = EditText(this).apply {
            hint = "Gemini API key"
            setText(prefs.getString("gemini", ""))
            setSingleLine()
        }
        val start = Button(this).apply { text = "Start Jarvis" }
        val stop = Button(this).apply { text = "Stop Jarvis" }
        val battery = Button(this).apply { text = "Battery settings (set Jarvis to No restrictions)" }
        val info = TextView(this).apply { text = "Say \"Hey Jarvis\" after starting." }

        listOf(gem, start, stop, battery, info).forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })

        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(perms.toTypedArray(), 1)

        start.setOnClickListener {
            prefs.edit()
                .putString("gemini", gem.text.toString().trim())
                .apply()
            ContextCompat.startForegroundService(this, Intent(this, JarvisService::class.java))
            info.text = "Jarvis starting. First time takes ~20 seconds to unpack the voice model, then say \"Jarvis\"."
        }
        stop.setOnClickListener {
            stopService(Intent(this, JarvisService::class.java))
            info.text = "Jarvis stopped."
        }
        battery.setOnClickListener {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }
}
